import { Cliente } from "./Cadastro.js";

let Cliente = new Cliente('camila','10','085-152-124-25')
console.log(Cliente)





